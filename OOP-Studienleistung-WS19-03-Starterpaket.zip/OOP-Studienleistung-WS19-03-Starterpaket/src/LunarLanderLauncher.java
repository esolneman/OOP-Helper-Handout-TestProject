import de.ur.mi.oop.launcher.GraphicsAppLauncher;


public class LunarLanderLauncher {

    public static void main(String[] args) {
        GraphicsAppLauncher.launch("LunarLander");
    }
}

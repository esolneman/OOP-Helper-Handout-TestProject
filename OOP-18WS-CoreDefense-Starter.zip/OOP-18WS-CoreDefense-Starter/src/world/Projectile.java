package world;

import de.ur.mi.graphics.Ellipse;
import de.ur.mi.graphics.GraphicsObject;

public class Projectile {
    private Ellipse projectile;

    private double speed;
    private double directionX;
    private double directionY;

    public Projectile() {
    }

    public void update() {
    }

    public void draw() {
        //projectile.draw();
    }

    public double getRadius() {
        return projectile.getWidth()/2.0;
    }

    public boolean hitTest(double x, double y) {
        return false;
    }

    public double distanceTo(GraphicsObject graphicsObject) {
        return projectile.distanceTo(graphicsObject);
    }
}

import de.ur.mi.graphics.Color;
import de.ur.mi.graphicsapp.GraphicsApp;
import game.GameManager;

import java.awt.event.KeyEvent;

public class CoreDefense extends GraphicsApp {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 800;
    public static final int FRAMERATE = 60;

    private GameManager gameManager;

    public void setup() {
        setupCanvas();
        setupGame();
    }

    private void setupGame() {
        gameManager = new GameManager();
    }

    private void setupCanvas() {
        size(WIDTH, HEIGHT);
        frameRate(FRAMERATE);
    }

    public void draw() {
        background(Color.BLACK);
        gameManager.update();
        gameManager.draw();
    }

    public void keyPressed(KeyEvent e) {
        // translate key presses into input commands for the game manager
    }

    public void keyReleased(KeyEvent e) {
        // translate key presses into input commands for the game manager
    }
}

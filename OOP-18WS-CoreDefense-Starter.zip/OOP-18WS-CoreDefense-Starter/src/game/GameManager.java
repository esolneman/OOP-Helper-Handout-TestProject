package game;

import de.ur.mi.geom.Point;
import world.Player;

public class GameManager {

    private static final int GAME_STATE_STARTED = 1;

    // Please use relative values for canvas related constants
    private static final int CANVAS_CENTER_X = 400;
    private static final int CANVAS_CENTER_Y = 400;

    private Player player;
    private int gameState = GAME_STATE_STARTED;

    public GameManager() {
        setupGameObjects();
    }

    public void update() {
    }

    public void draw() {
        player.draw();
    }

    public void transmitMovementCommand(/* MovementType type */) {
    }

    ///////////////////////////////////////////////////////////////////////////

    private void setupGameObjects() {
        Point orbitCenter = new Point(CANVAS_CENTER_X, CANVAS_CENTER_Y);

        player = new Player(/* insert parameters here */);
    }

    private void checkAndHandleCollision() {
    }

}
